<?php
/**
 * Created by PhpStorm.
 * User: Hebron
 * Date: 2/7/2019
 * Time: 11:08 AM
 */
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET,PUT,POST,DELETE');
header('Access-Control-Max-Age:1000');
header('Access-Control-Allow-Headers: Origin,Content-Type,X-Auth-Token,Authorization');

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

require '../vendor/autoload.php';

// Create and configure Slim app
$config = ['settings' => [
    'addContentLengthHeader' => false,
   'displayErrorDetails' => true,
    'db' => [
        'host'=>'localhost',
        'user'=>'root',
        'pass'=>'',
        'db_name'=>'healthydb'
]
]];
$app = new \Slim\App($config);
require 'dependencies.php';


$app->post('/login', function (Request $req,  Response $res, $args = []) {
    //    $myvar1 = $req->getParam('myvar'); //checks both _GET and _POST [NOT PSR-7 Compliant]
        $username = $req->getParsedBody()['username']; 
        $password = $req->getParsedBody()['password']; 
        $password= md5($password);
        $sql ="SELECT * FROM tbl_user WHERE USERNAME='".$username."' AND PASSWORD='".$password."'";
        $jah= $this->db->prepare($sql);
        $jah->execute();
        $result= array();
        if ($jah->rowCount()>0){
              $rows= $jah->fetch();
    $result['status']= 200;
    $result['data']=[
    'username' =>$rows['username'],
    'firstname' =>$rows['firstname'],
    'lastname' =>$rows['lastname'],

];
}
else {
    $result['status']= 400;
}
return $res->withJson($result);

    });
    $app->post('/register_facility', function (Request $req,  Response $res, $args = []) {
            $facility_name = $req->getParsedBody()['name']; 
            $facility_description = $req->getParsedBody()['description']; 
           $quel= "INSERT INTO `tbl_facility`(`id`, `name`, `description`) VALUES (NULL,'".$facility_name."','".$facility_description ."')";
            $jah= $this->db->prepare($quel);
            $jah->execute();
            if ($jah->rowCount()>0)
            {
                $result=array(
                    'status'=>200,
                    'data'=>'success'


                );
            }
               else {
                $result=array(
                    'status'=> 400,
                    'data'=>'data not iserted'
                );  
               }
               return $res->withJson($result);
            });

            $app->post('/register_service', function (Request $req,  Response $res, $args = []) {
                $facility_name = $req->getParsedBody()['name']; 
                $facility_description = $req->getParsedBody()['description']; 
               $quel= "INSERT INTO `tbl_service_type`(`id`, `name`, `description`) VALUES (NULL,'".$facility_name."','".$facility_description ."')";
                $jah= $this->db->prepare($quel);
                $jah->execute();
                if ($jah->rowCount()>0)
                {
                    $result=array(
                        'status'=>200,
                        'data'=>'success'
    
    
                    );
                }
                   else {
                    $result=array(
                        'status'=> 400,
                        'data'=>'data not iserted'
                    );  
                   }
                   return $res->withJson($result);
                });
                
            $app->post('/registered_service', function (Request $req,  Response $res, $args = []) {
                $service_name = $req->getParsedBody()['name']; 
                $facility_id = $req->getParsedBody()['facility_id']; 
                $service_id = $req->getParsedBody()['service_id']; 
               $quel= "INSERT INTO `tbl_service`(`id`, `name`, `facilicy_id`,`service_type_id`) VALUES (NULL,'".$service_name."','".$facility_id."','".$service_id."')";
                $jah= $this->db->prepare($quel);
                $jah->execute();
                if ($jah->rowCount()>0)
                {
                    $result=array(
                        'status'=>200,
                        'data'=>'success'
                    );
                }
                   else {
                    $result=array(
                        'status'=> 400,
                        'data'=>'data not iserted'
                    );  
                   }
                   return $res->withJson($result);
                });
                
        $app->get('/view', function (Request $req,  Response $res, $args = []) {
                $sql ="SELECT `tbl_service`.`id`,`tbl_service`.`name`,`tbl_service_type`.`name` as service_type_name,`tbl_facility`.`name` as facility_name FROM `tbl_service_type`,`tbl_service`,`tbl_facility` WHERE `tbl_service`.`facilicy_id`=`tbl_facility`.`id` AND `tbl_service`.`service_type_id`=	`tbl_service_type`.`id`";
                $jah= $this->db->prepare($sql);
                $jah->execute();
                $result= array();
                if ($jah->rowCount()>0){
            $result=$jah->fetchAll(PDO::FETCH_OBJ);
        return $res->withJson($result);
        }
        else {
            return $res->withJson($result);
        }
    
            });


    
            $app->get('/facility', function (Request $req,  Response $res, $args = []) {
                $sql ="SELECT * FROM `tbl_facility`";
                $jah= $this->db->prepare($sql);
                $jah->execute();
                $result= array();
                if ($jah->rowCount()>0){
            $result=$jah->fetchAll(PDO::FETCH_OBJ);
        return $res->withJson($result);
        }
        else {
            return $res->withJson($result);
        }
    
            });



            $app->get('/viewservice', function (Request $req,  Response $res, $args = []) {
                $sql ="SELECT * FROM `tbl_service_type`";
                $jah= $this->db->prepare($sql);
                $jah->execute();
                $result= array();
                if ($jah->rowCount()>0){
            $result=$jah->fetchAll(PDO::FETCH_OBJ);
        return $res->withJson($result);
        }
        else {
            return $res->withJson($result);
        }
    
            });

$app->run();