<?php
/**
 * Created by PhpStorm.
 * User: Hebron
 * Date: 2/11/2019
 * Time: 10:47 AM
 */


$container = $app->getContainer();
$container['db'] = function ($c){
    $setting = $c->get('settings')['db'];
    $pdo = new PDO("mysql:host={$setting['host']};dbname={$setting['db_name']}","{$setting['user']}","{$setting['pass']}");
//    $pdo = new PDO("mysql:host=localhost;dbname=test",'root','');

    return $pdo;
};