import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../service/user-service.service';

@Component({
  selector: 'app-facility',
  templateUrl: './facility.component.html',
  styleUrls: ['./facility.component.css']
})
export class FacilityComponent implements OnInit {

  facilityname:any=""
  facilitydescription:any=""
  ujumbe=''
  constructor(private user_service:UserServiceService) { }

  ngOnInit() {
  }

  faicilityreg(){
    this.user_service.facility(this.facilityname,this.facilitydescription).subscribe((res: any)=>{
      if (res['status']==200)
      {
        this.ujumbe="Data is inserted successfully";
      }
      else{
        this.ujumbe="Data is not inserted successfully";
      }
    });
  }

}
