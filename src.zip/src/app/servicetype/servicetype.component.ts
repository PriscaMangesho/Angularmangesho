import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../service/user-service.service';

@Component({
  selector: 'app-servicetype',
  templateUrl: './servicetype.component.html',
  styleUrls: ['./servicetype.component.css']
})
export class ServicetypeComponent implements OnInit {

  servicecategory:any = ''
  servicedescription:any = ''
  private ujumbe:any = "";

  constructor(private user_service:UserServiceService,) { }

  ngOnInit() {
  }

  servicetype(){
    this.user_service.servicetype(this.servicecategory,this.servicedescription).subscribe((res: any)=>{
      if (res['status']==200)
      {
        this.ujumbe="Data is inserted successfully";
      }
      else{
        this.ujumbe="Data is not inserted successfully";
      }
    });
  }
}
