import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../service/user-service.service';


@Component({
  selector: 'app-listservice',
  templateUrl: './listservice.component.html',
  styleUrls: ['./listservice.component.css']
})
export class ListserviceComponent implements OnInit {

  registeredservices:any
  constructor(private user_service:UserServiceService) { }

  ngOnInit() {
    this.user_service.viewregisteredservices().subscribe((res: any)=>{
      this.registeredservices = res;
      
  });
  }

}
