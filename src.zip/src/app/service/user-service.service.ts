import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';

const httpOptions={
  headers:new HttpHeaders({
    'Content-Type':'application/json',
    'Authorization': 'any-auth-token'
  })
};

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(
  public http: HttpClient
  ) { }
  url="http://localhost/example/slim_apii/public/login";

  url_service_type="http://localhost/example/slim_apii/public/register_service";
  url_facility="http://localhost/example/slim_apii/public/register_facility";
  url_view_facility="http://localhost/example/slim_apii/public/facility";
  url_view_service="http://localhost/example/slim_apii/public/viewservice";
  url_servicereg="http://localhost/example/slim_apii/public/registered_service";
  url_serviceview="http://localhost/example/slim_apii/public/view";

  
  login(username:string,password:string){
    return this.http.post(this.url,
    {
      'username': username,
      'password': password
    },
    httpOptions);
  }


  servicetype(servicename,servicedesc){
    return this.http.post(this.url_service_type,
      {
        'name': servicename,
        'description': servicedesc
      },
      httpOptions);
  }

  facility(facilityname,facilitydescription){
    return this.http.post(this.url_facility,
      {
        'name': facilityname,
        'description': facilitydescription
      },
      httpOptions);
  }

  
  viewfacility(){
    return this.http.get(this.url_view_facility);
  }

    
  viewservice(){
    return this.http.get(this.url_view_service);
  }

  servicereg(selectedfacility,selectedservice,name){
    return this.http.post(this.url_servicereg,
      {
        'name': name,
        'facility_id': selectedfacility,
        'service_id': selectedservice
      },
      httpOptions);
  }

  viewregisteredservices(){
    return this.http.get(this.url_serviceview);
  }
}
