import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../service/user-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public username:any
  public password:any
  constructor(
    private user_service:UserServiceService,
    private jah:Router) { }

  ngOnInit() {
  }
  sign(){
    this.user_service.login(this.username,this.password).subscribe((res: any)=>{
      if (res['status']==200)
      {
        // console.log(res)
             this.jah.navigate(['/home']);
             
      }
      else{
        this.jah.navigate(['/login']);
      }
    });
  
  }

}
