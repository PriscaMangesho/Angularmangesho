import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../service/user-service.service';

 
@Component({
  selector: 'app-serviceregistration',
  templateUrl: './serviceregistration.component.html',
  styleUrls: ['./serviceregistration.component.css']
})
export class ServiceregistrationComponent implements OnInit {
  servicetypedata:any
  facilitydata:any
  selectedservice:any
  selectedfacility:any
  name:any
  ujumbe:any
  id:any
  constructor(private user_service:UserServiceService) { }

  ngOnInit() {
    this.user_service.viewfacility().subscribe((res: any)=>{
      this.facilitydata = res;
    });

    this.user_service.viewservice().subscribe((res: any)=>{
      this.servicetypedata = res;
    });
  }

  servicereg(){
    this.user_service.servicereg(this.selectedfacility,this.selectedservice,this.name).subscribe((res: any)=>{
        this.ujumbe = "Service registerd successfully";
        
    });
  }

  getSelectedOptionText(event) {
    this.id = event.target.value; 
 }

 getSelected(event) {
  this.id = event.target.value; 
}

}
